/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project2;

/**
 *
 * @author user
 */
public class Account {
        double balance;
    public void withdraw(double amount){
        
        if (amount>balance){
         System.out.print("Insuffecient Funds");
        }else{
        balance = balance - amount;
        System.out.print("\n Withdrawal succesful ");
        System.out.print("Your balace is " + this.balance);
                }
        
    }
        public void deposit(double amount){
        if(amount >0){
            
            balance = balance + amount;
            System.out.print("\nDeposit Successful");
            System.out.print(" Your balace is" + this.balance);
        }else{
            System.out.print("\n Invalid Amount for deposit");
    }
     

    }
            public double checkBalance(){
        
        return this.balance;
        }
}
