/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project2;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author Phumelele Miya Bank app
 */
public class Project2 {

    public static void main(String[] args) {

atm teller1 = new atm();
Scanner scan = new Scanner(System.in);
do {
       
        System.out.println("\nWhat would you like to do\n[B]alance Check\n[D]eposit \n[W]ithdraw \n[E]xit");
        
        String answ = scan.nextLine();
        teller1.takeAct(answ);
}while (!(String.valueOf(scan.nextLine()).equalsIgnoreCase("E")));
        

    }
}
