/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project_1;

/**
 *
 * @author user
 */
public class Subject1 {
        double Mark;
        public double getMark(){
        
        return this.Mark;
    }
    public void setMark(double Mark){
        this.Mark = Mark;
    }
     public String getGrade(double mark){
        if(mark > 85){
                return " A+";
        }else if(mark > 80){
                return " A ";
        }else if(mark > 70){
             return " B ";
     }else if(mark > 60){
               return " C ";
}else if(mark > 50){
                return " D ";
}else if(mark > 40){
                return " E ";
}else if(mark > 30){
                return " F ";
}else if(mark > 20){
                return " G ";
}else if(mark > 10){
                return " H ";
}else {
            return " HH ";
}             
         

        }
    }


