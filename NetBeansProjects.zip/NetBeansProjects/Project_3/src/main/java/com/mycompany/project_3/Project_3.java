/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project_3;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class Project_3 {

    public static void main(String[] args) {
        PickNum digiGame = new PickNum();
        int nmbr = digiGame.pickAndDisplay();
                int i = 4;

  System.out.print("\nEnter your guess from 1- 6");
  Scanner scan = new Scanner(System.in);
  int guess = scan.nextInt();
  if (guess == nmbr){
      System.out.print("\nCongratulations That's Correct");
  }else{
  while (i > 0) {
  System.out.println("\nyou have  " + i + " attempts" );
    System.out.println("\nEnter your guess from 1- 6");
   guess = scan.nextInt();
   if (guess>nmbr){
       System.out.println("\nThe chosen number is less");
   }else if(guess<nmbr){
       System.out.println("\nThe chosen number is more");
   }else if (guess==nmbr){
       System.out.println("Congratulations, That's Correct");
   } else      if(i==0){
       System.out.println("Game Over");
       System.out.println("The number is " + nmbr);
 --i;
     }
   i--;
  }

 }    
        
}

}
