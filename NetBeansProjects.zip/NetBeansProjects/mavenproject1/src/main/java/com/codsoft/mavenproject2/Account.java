/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.codsoft.mavenproject2;

/**
 *
 * @author user
 */
public class Account {
    double balance = 150.00;
    public void withdraw(double amount){
        if (amount>this.balance){
            system.out.print("Insuffecient Funds");
        }else{
        this.balance = this.balance - amount;
        system.out.print("\n Withdrawal succesful");
                }
    }
        public void deposit(double amount){
        if(amount >0){
            this.balance = this.balance + amount;
            system.out.print("\nDeposit Successful");
        }else{
            system.out.print("\n Invalid Amount for deposit");
    }
        
    }
        
        
}
