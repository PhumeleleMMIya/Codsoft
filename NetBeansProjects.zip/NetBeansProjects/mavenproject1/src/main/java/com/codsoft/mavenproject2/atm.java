/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.codsoft.mavenproject2;

/**
 *
 * @author user
 */
import java.util.Scanner;
import java.util.String;
import java.util.*;

public class atm {
    double balance;
    
    public void takeAct(String answ){
    Scanner scan = new Scanner(System.in);
    switch(answ){
        case "W" | "w":
            system.out.println("\nHow much do you want to withdraw?");
            this.withdraw(Scan.nextLine());
        case "D" | "d":
            system.out.println("\nHow much do you want to deposit");
            this.deposit(Scan.nextLine());
        case "C" | "c":
            Account Acc = new Account();
            system.out.println("\nYour balance is " + Acc.balance);
            
        }
    }
}
