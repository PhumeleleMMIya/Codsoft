/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.Scanner;

public class Task3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        system.out.println("\nWhat would you like to do\n[B]alance Check\n[D]eposit \n[W]ithdraw");
        Scanner scan = new Scanner(System.in);
        Atm teller1 = new Atm();
        String answ = scan.nextLine();
        teller1.takeAct(answ);
        
        
    }
}
