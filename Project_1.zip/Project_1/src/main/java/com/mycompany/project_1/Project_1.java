/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project_1;

/**
 *
 * @author Phumelele Mango Miya Grading app
 */
import java.util.Scanner;
import java.util.* ;
public class Project_1 {

    public static void main(String[] args) {
       
        Subject1 s1 = new Subject1() ;
        Subject1 s2 = new Subject1() ;
        Subject1 s3 = new Subject1() ;
        Subject1 s4 = new Subject1();
        Subject1 s5 = new Subject1();
        Subject1 s6 = new Subject1();
     Scanner scan = new Scanner(System.in);
     System.out.println("\nPlease enter your mark for Subject 1: (0% - 100%)");
     
     s1.setMark(scan.nextDouble());
     System.out.println("\nPlease enter your mark for Subject 2: (0% - 100%)");
     s2.setMark(scan.nextDouble());
     System.out.println("\nPlease enter your mark for Subject 3: (0% - 100%)");
     s3.setMark(scan.nextDouble());
     System.out.println("\nPlease enter your mark for Subject 4: (0% - 100%)");
     s4.setMark(scan.nextDouble());
     System.out.println("\nPlease enter your mark for Subject 5: (0% - 100%)");
     s5.setMark(scan.nextDouble());
     System.out.println("\nPlease enter your mark for Subject 6: (0% - 100%)");
     s6.setMark(scan.nextDouble());
 double avg = (s1.getMark() + s2.getMark() + s3.getMark() + s4.getMark() + s5.getMark() + s6.getMark())/6 ;
 
 System.out.println("\nYour average is " + avg);
 System.out.println("\nSubject 1" + s1.getGrade(s1.getMark()));
 System.out.println("\nSubject 2" + s2.getGrade(s2.getMark()));
 System.out.println("\nSubject 3" + s3.getGrade(s3.getMark()));
 System.out.println("\nSubject 4" + s4.getGrade(s4.getMark()));
 System.out.println("\nSubject 5" + s5.getGrade(s5.getMark()));
 System.out.println("\nSubject 6" + s6.getGrade(s6.getMark()));
    }
}
