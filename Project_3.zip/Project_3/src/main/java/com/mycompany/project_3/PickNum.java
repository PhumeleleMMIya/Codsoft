/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project_3;

/**
 *
 * @author user
 */
public class PickNum {
         public int pickAndDisplay(){
       return (int) (Math.random()* 7)+1;
        
     }
}
