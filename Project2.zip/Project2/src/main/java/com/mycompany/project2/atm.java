/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project2;

/**
 *
 * @author user
 */
import java.util.Scanner;
import java.util.*;
public class atm {
        double balance;
    Account Acc = new Account();
    public void takeAct(String answ){
    Scanner scan = new Scanner(System.in);
    
    switch(answ){
        case "W":
            System.out.println("\nHow much do you want to withdraw?");
            Acc.withdraw(scan.nextDouble());
            break;
            case "w":
            System.out.println("\nHow much do you want to withdraw?");
            Acc.withdraw(scan.nextDouble());
            break;
        case "d":
            System.out.println("\nHow much do you want to deposit");
            Acc.deposit(scan.nextDouble());
            break;
        case "D":
            System.out.println("\nHow much do you want to deposit");
           Acc.deposit(scan.nextDouble());
            break;
        case "B":
            
            System.out.println("\nYour balance is " + Acc.checkBalance());
            break;
        case  "b":
            System.out.println("\nYour balance is " + Acc.checkBalance());
            break;
        case "e":
            System.out.print("\n Confirm [E]xit");
            break;
        case "E":
            System.out.print("\n Confirm [E]xit");
            break;
            
        }
    
}
}
